import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Sınav Notu: ");
		int score = scanner.nextInt();
		
		if(score >=85 && score <= 100) {
			System.out.println("AA");
		}else if (score >=75 && score <=85) {
			System.out.println("BA");
		}else if (score >= 65 && score <= 75) {
			System.out.println("BB");
		}else if (score >=60& score <= 65) {
			System.out.println("CB");
		}else if (score >= 50 && score <= 60) {
			System.out.println("CC");
		}else if (score >= 40 && score <= 50) {
			System.out.println("DC");
		}else if (score >= 35 && score <= 40) {
			System.out.println("DD");
		}else if (score >= 0 && score <= 35) {
			System.out.println("FF");
		}else {
			System.out.println("Geçerli Bir Not Giriniz!!!!!");
		}
	}
}
