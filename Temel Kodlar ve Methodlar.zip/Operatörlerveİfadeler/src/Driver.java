import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
//		int x;
//		x=10;
////		x++; //Kendisine verilen değişkeni 1 arttırmak
////		x= x+1; // Üsttekiyle aynıdır
//		System.out.println(x++);
//		System.out.println(x);
//		
//		System.out.println(--x);
//		
//		System.out.println(5%2);//5'in 2'ye bölümünden kalan sayıyı yazar
//		
//		Scanner scanner = new Scanner(System.in);
//		System.out.println("Lutfen bir sayi giriniz: ");
//		int a= scanner.nextInt();
//		System.out.println(a % 2 ==0 ? " Cift Sayi" : "Tek Sayı");
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Lutfen parolanizi giriniz: ");
		String password = scanner.nextLine();
		boolean isOk = password.equals("1234");
		System.out.println(isOk ? "Parolanız Dogru" : "Parolanız Yanlis");
	}

}
