
public class Driver {
	public static void main(String[] args) {
		int x=11+3*2; // (11 + (3 * 2))
		System.out.println(x);
		
		int y = 11 + (3*2);
		System.out.println(y);
	}

}
