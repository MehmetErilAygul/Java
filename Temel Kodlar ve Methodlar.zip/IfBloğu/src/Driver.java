import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
//		int number = -10;
//		
//		boolean result = number > 0;
//		
//		if (result ) {
//			System.out.println("Number Pozitif");
//			System.out.println("2.");
//		}
//		else {
//			System.out.println("Number negatif bir sayıdır.");
//		}
//		
//		System.out.println("Burası her zaman Çalıştırılacak");
		
		
		
		//////////----------Pozitif ve Negatif Sayı Girme
		
//		Scanner scanner = new Scanner(System.in);
//		System.out.println("Lütfen Bir sayı giriniz: ");
//		int number = scanner.nextInt();
//				if(number>0) {
//					System.out.println("Pozitif Bir Sayı Girdiniz.");
//				}
//				else {
//					System.out.println("Negatif Bir Sayı Girdiniz.");
//				}
		
		
		
		
//		////////////-----------Tek ve Çift Sayı Girme
		
		
		
//		Scanner scanner = new Scanner(System.in);
//		System.out.println("Lütfen Bir sayı giriniz: ");
//		int number = scanner.nextInt();
//				if(number % 2 ==0) {
//					System.out.println("Çift Bir sayı Girdiniz");
//				}
//				else {
//					System.out.println("Tek bir Sayı Girdiniz.");
//				}
//					
		
		
		///////-------Aralık Belirlemeli Yazım
		
//		int number = 75;
//		
//		if(number <100) {
//			System.out.println("Sayi 100'den Kucuk");
//			if(number >50) {
//				System.out.println("Sayi 50'den Buyuk");
//			}
//		}
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Lütfen Bir Sayı Giriniz: ");
		int number = scanner.nextInt();
		if(number<100 && number >=10) {
			System.err.println("Girdiğiniz sayı 2 basamaklı");			
		}
		else if(number <1000 && number >=100) {
			System.out.println("Girdiğiniz sayı 3 basamaklı");
		}
		else if(number <10000 && number >=1000) {
			System.out.println("Girdiğiniz sayı 4 basamaklı");
		}
		else {
			System.out.println("Girdiğiniz sayı 10 ve 9999 arasında değil");
		}
		
	}
}
