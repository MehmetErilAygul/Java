
public class Driver {

	public static void main(String[] args)
	{
		String firstname = "John";
		System.out.println(firstname.charAt(1));
		System.out.println(firstname.toUpperCase());
		System.out.println(firstname.toLowerCase());
		System.out.println(firstname.replace("o", "a"));
		System.out.println(firstname.length());
		System.out.println(firstname.substring(2));
		System.out.println(firstname);
	}
}
