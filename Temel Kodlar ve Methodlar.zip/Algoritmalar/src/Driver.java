import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int toplam=0;
		int input=0;
		do {
			System.out.print("Bir sayı Giriniz: ");
			input=scanner.nextInt();
			toplam+=input;
		}while(input !=0);
		System.out.println("Girilen Sayıların Toplamı = " + toplam);
	}

}
