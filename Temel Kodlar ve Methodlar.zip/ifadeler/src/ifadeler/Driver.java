package ifadeler;

import java.util.Iterator;

public class Driver {

	public static void main(String[] args) {
		int i; //Expression
		int x= 10; //Decleration
		System.out.println("Selam");
		double pow = Math.pow(2, 3);
		System.out.println(pow);
		
		for (int j = 0; j < 10; j++) {
			System.out.println(j);
		}
		
	}
}
