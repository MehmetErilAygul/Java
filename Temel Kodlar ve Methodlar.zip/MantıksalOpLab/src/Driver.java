
public class Driver {
	public static void main(String[] args) {
		boolean a = false;
		boolean b = true;
		
		System.out.println(a && b);
		System.out.println(a || b);
		System.out.println(!a && b);
	}

}
